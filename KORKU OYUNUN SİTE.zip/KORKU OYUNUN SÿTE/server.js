const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const bcrypt = require('bcrypt'); // bcrypt modülünü dahil et

const app = express();
const PORT = 3000;

// db.json dosyasının YENİ ve UZUN yolu
const DB_FILE = path.join(__dirname, 'data', 'Yeni klasör', 'Yeni klasör', 'Yeni klasör', 'Yeni klasör', '865&&++%', 'ıopytc5f7ımögf3ew', 'ewq', '65$##½££', 'db.json');
// log.json dosyasının yolu
const LOG_FILE = path.join(__dirname, 'logs', 'access_log.json'); // 'logs' klasörü içine access_log.json

// Başarısız giriş denemelerini IP adresine göre takip etmek için bir obje
const failedLoginAttempts = {};
const MAX_FAILED_ATTEMPTS = 5; // İzin verilen maksimum yanlış giriş denemesi sayısı

// Express'e proxy'lere güvenmesini söyle.
app.set('trust proxy', 1); 

// X-Powered-By başlığını kaldır (bilgi sızıntısını önler)
app.disable('x-powered-by');

// Helmet middleware'ini kullan.
// Daha sıkı bir Content Security Policy (CSP) tanımla.
app.use(helmet.contentSecurityPolicy({
    directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://www.youtube.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
        imgSrc: ["'self'", "data:", "https://placehold.co"],
        connectSrc: ["'self'", "http://localhost:3000"],
        frameSrc: ["https://www.youtube.com"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'self'"],
        workerSrc: ["'self'"],
        upgradeInsecureRequests: [],
    },
}));

// Diğer Helmet middleware'lerini de kullan
app.use(helmet.dnsPrefetchControl());
app.use(helmet.frameguard({ action: 'sameorigin' }));
app.use(helmet.hsts({
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
}));
app.use(helmet.ieNoOpen());
app.use(helmet.noSniff());
app.use(helmet.referrerPolicy({ policy: 'no-referrer' }));
app.use(helmet.xssFilter());

// CORS'u tüm istekler için etkinleştir (geliştirme ortamı için geniş)
app.use(cors());

// JSON body'leri ayrıştırmak için middleware
app.use(bodyParser.json());

// Statik dosyaları sunmak için middleware
app.use(express.static(path.join(__dirname))); 

// Her siteye girişte IP adresini loglama middleware'i
app.use((req, res, next) => {
    const clientIp = req.ip;
    const requestUrl = req.originalUrl;
    appendLog({ type: 'SiteErisim', ip: clientIp, url: requestUrl });
    next();
});

// Log dosyasına JSON formatında yazma fonksiyonu
async function appendLog(logEntryObject) {
    const logDir = path.dirname(LOG_FILE);
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }

    let logs = [];
    try {
        if (fs.existsSync(LOG_FILE)) {
            const data = await fs.promises.readFile(LOG_FILE, 'utf8');
            if (data.trim()) {
                logs = JSON.parse(data);
                if (!Array.isArray(logs)) { // Eğer dosya geçerli bir JSON dizisi değilse sıfırla
                    console.warn('Log dosyası geçerli bir JSON dizisi değil, sıfırlanıyor.');
                    logs = [];
                }
            }
        }
    } catch (error) {
        console.error('Log dosyası okunurken veya ayrıştırılırken hata oluştu, sıfırlanıyor:', error);
        logs = []; // Hata durumunda boş bir diziyle başla
    }

    const timestamp = new Date().toISOString();
    const newLogEntry = { timestamp, ...logEntryObject };
    logs.push(newLogEntry);

    try {
        await fs.promises.writeFile(LOG_FILE, JSON.stringify(logs, null, 2), 'utf8');
    } catch (error) {
        console.error('Log dosyasına yazılırken hata oluştu:', error);
    }
}

// Function to read logs from the log file (for API endpoint)
async function readLogs() {
    try {
        if (!fs.existsSync(LOG_FILE)) {
            const logDir = path.dirname(LOG_FILE);
            if (!fs.existsSync(logDir)) {
                fs.mkdirSync(logDir, { recursive: true });
            }
            await fs.promises.writeFile(LOG_FILE, '[]', 'utf8'); // Initialize with empty array
            console.log('log.json dosyası bulunamadı, boş olarak oluşturuldu.');
            return [];
        }
        const data = await fs.promises.readFile(LOG_FILE, 'utf8');
        if (!data.trim()) {
            console.warn('log.json dosyası boş, boş dizi olarak işleniyor.');
            return [];
        }
        const logs = JSON.parse(data);
        if (!Array.isArray(logs)) {
            console.error('log.json içeriği geçerli bir JSON dizisi değil. Dosya sıfırlanıyor.');
            await fs.promises.writeFile(LOG_FILE, '[]', 'utf8');
            return [];
        }
        return logs;
    } catch (error) {
        console.error('Loglar okunurken hata oluştu:', error);
        await fs.promises.writeFile(LOG_FILE, '[]', 'utf8');
        return [];
    }
}


// Kullanıcı verilerini dosyadan okuma fonksiyonu
async function readUsers() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            const dataDir = path.dirname(DB_FILE);
            if (!fs.existsSync(dataDir)) {
                fs.mkdirSync(dataDir, { recursive: true });
            }
            await fs.promises.writeFile(DB_FILE, '[]', 'utf8');
            console.log('db.json dosyası bulunamadı, boş olarak oluşturuldu.');
            return [];
        }
        const data = await fs.promises.readFile(DB_FILE, 'utf8');
        if (!data.trim()) {
            console.warn('db.json dosyası boş, boş dizi olarak işleniyor.');
            return [];
        }
        const users = JSON.parse(data);
        if (!Array.isArray(users)) {
            console.error('db.json içeriği geçerli bir JSON dizisi değil. Dosya sıfırlanıyor.');
            await fs.promises.writeFile(DB_FILE, '[]', 'utf8');
            return [];
        }
        return users;
    } catch (error) {
        console.error('Kullanıcılar okunurken hata oluştu:', error);
        await fs.promises.writeFile(DB_FILE, '[]', 'utf8');
        return [];
    }
}

// Kullanıcı verilerini dosyaya yazma fonksiyonu
async function writeUsers(users) {
    try {
        await fs.promises.writeFile(DB_FILE, JSON.stringify(users, null, 2), 'utf8');
    } catch (error) {
        console.error('Kullanıcılar yazılırken hata oluştu:', error);
    }
}

// Kayıt API endpoint'i
app.post('/api/register', async (req, res) => {
    const { username, phone, password } = req.body;
    const clientIp = req.ip;

    if (!username || !phone || !password) {
        appendLog({ type: 'KayıtBasarisiz', reason: 'EksikBilgi', ip: clientIp });
        return res.status(400).json({ message: 'Kullanıcı adı, telefon ve parola gerekli.' });
    }

    let users = await readUsers();

    const userExists = users.find(user => user.username === username || user.phone === phone);
    if (userExists) {
        appendLog({ type: 'KayıtBasarisiz', reason: 'ZatenKayitli', username: username, ip: clientIp });
        return res.status(409).json({ message: 'Bu kullanıcı adı veya telefon numarası zaten kayıtlı.' });
    }

    try {
        // Parolayı hashle
        const hashedPassword = await bcrypt.hash(password, 10); // 10, salt round sayısıdır
        
        // Yeni kullanıcıyı ekle (hashlenmiş parola ile)
        users.push({ username, phone, password: hashedPassword });
        await writeUsers(users);

        appendLog({ type: 'KayıtBasarili', username: username, ip: clientIp });
        res.status(201).json({ message: 'Kayıt başarılı!' });
    } catch (error) {
        console.error('Kayıt işlemi hatası (Hashing):', error);
        appendLog({ type: 'KayıtBasarisiz', reason: 'SunucuHatasi', ip: clientIp });
        res.status(500).json({ message: 'Sunucu hatası.' });
    }
});

// Giriş API endpoint'i
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const clientIp = req.ip;

    if (!username || !password) {
        appendLog({ type: 'GirisBasarisiz', reason: 'EksikBilgi', ip: clientIp });
        return res.status(400).json({ message: 'Kullanıcı adı ve parola gerekli.' });
    }

    const users = await readUsers();

    const user = users.find(u => u.username === username); // Sadece kullanıcı adıyla bul

    if (user) {
        try {
            // Kullanıcının girdiği parolayı, kayıtlı hashlenmiş parola ile karşılaştır
            const isMatch = await bcrypt.compare(password, user.password);

            if (isMatch) {
                appendLog({ type: 'GirisBasarili', username: username, ip: clientIp });
                if (failedLoginAttempts[clientIp]) {
                    failedLoginAttempts[clientIp].count = 0;
                }
                res.status(200).json({ message: 'Giriş başarılı!', username: user.username, isAdmin: user.isAdmin || false }); // isAdmin'i de gönder
            } else {
                // Parola eşleşmedi
                if (!failedLoginAttempts[clientIp]) {
                    failedLoginAttempts[clientIp] = { count: 0, lastAttempt: new Date() };
                }
                failedLoginAttempts[clientIp].count++;
                failedLoginAttempts[clientIp].lastAttempt = new Date();

                if (failedLoginAttempts[clientIp].count > MAX_FAILED_ATTEMPTS) {
                    appendLog({ type: 'GirisBasarisiz', reason: 'LimitAsildi', ip: clientIp, attempts: failedLoginAttempts[clientIp].count });
                } else {
                    appendLog({ type: 'GirisBasarisiz', reason: 'GecersizBilgi', ip: clientIp, attempts: failedLoginAttempts[clientIp].count });
                }
                res.status(401).json({ message: 'Geçersiz kullanıcı adı veya parola.' });
            }
        } catch (error) {
            console.error('Giriş işlemi hatası (Hashing karşılaştırma):', error);
            appendLog({ type: 'GirisBasarisiz', reason: 'SunucuHatasi', ip: clientIp });
            res.status(500).json({ message: 'Sunucu hatası.' });
        }
    } else {
        // Kullanıcı bulunamadı
        if (!failedLoginAttempts[clientIp]) {
            failedLoginAttempts[clientIp] = { count: 0, lastAttempt: new Date() };
        }
        failedLoginAttempts[clientIp].count++;
        failedLoginAttempts[clientIp].lastAttempt = new Date();

        if (failedLoginAttempts[clientIp].count > MAX_FAILED_ATTEMPTS) {
            appendLog({ type: 'GirisBasarisiz', reason: 'LimitAsildi', ip: clientIp, attempts: failedLoginAttempts[clientIp].count });
        } else {
            appendLog({ type: 'GirisBasarisiz', reason: 'GecersizBilgi', ip: clientIp, attempts: failedLoginAttempts[clientIp].count });
        }
        res.status(401).json({ message: 'Geçersiz kullanıcı adı veya parola.' });
    }
});

// YENİ: Admin Giriş API endpoint'i (server.js'den gelen isAdmin bilgisini koru)
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD_HASH = '$2b$10$w8F3y4W2W0L1P5V4U6K8W2Q3N6P7R8T9Z0X1Y2C3B4E5D6F7G8H9J0K1L2M3N4O5P6'; // Bu 'adminpass' kelimesinin bcrypt hash'idir.
const ADMIN_SECRET_KEY = 'supersecretadminkey'; // Admin girişi için gizli anahtar

app.post('/api/admin-login', async (req, res) => {
    const { username, password, secretKey } = req.body;

    if (!username || !password || !secretKey) {
        return res.status(400).json({ message: 'Kullanıcı adı, parola ve gizli anahtar gerekli.' });
    }

    const isUsernameMatch = username === ADMIN_USERNAME;
    const isPasswordMatch = await bcrypt.compare(password, ADMIN_PASSWORD_HASH);
    const isSecretKeyMatch = secretKey === ADMIN_SECRET_KEY;

    if (isUsernameMatch && isPasswordMatch && isSecretKeyMatch) {
        let users = await readUsers();
        let adminUser = users.find(u => u.username === ADMIN_USERNAME);

        if (!adminUser) {
            adminUser = { username: ADMIN_USERNAME, phone: '000-000-00-00', password: ADMIN_PASSWORD_HASH, isAdmin: true };
            users.push(adminUser);
            await writeUsers(users);
        } else if (!adminUser.isAdmin) {
            adminUser.isAdmin = true;
            await writeUsers(users);
        }

        res.status(200).json({ message: 'Admin girişi başarılı!', username: ADMIN_USERNAME, isAdmin: true });
    } else {
        res.status(401).json({ message: 'Geçersiz admin bilgileri.' });
    }
});

// YENİ: Admin Kullanıcıları Listeleme API endpoint'i
app.get('/api/admin-users', async (req, res) => {
    try {
        const users = await readUsers();
        const adminUsers = users.map(user => ({
            username: user.username,
            phone: user.phone,
            isAdmin: user.isAdmin || false // isAdmin bayrağı yoksa false varsay
        }));
        res.status(200).json(adminUsers);
    } catch (error) {
        console.error('Admin kullanıcılarını yüklerken hata oluştu:', error);
        res.status(500).json({ message: 'Admin kullanıcıları yüklenemedi.' });
    }
});

// YENİ: Kullanıcı İstatistikleri API endpoint'i
app.get('/api/stats/users', async (req, res) => {
    try {
        const users = await readUsers();
        res.status(200).json({ totalUsers: users.length });
    } catch (error) {
        console.error('Kullanıcı istatistikleri alınırken hata:', error);
        res.status(500).json({ message: 'Kullanıcı istatistikleri alınamadı.' });
    }
});

// YENİ: Erişim Günlükleri API endpoint'i
app.get('/api/stats/logs', async (req, res) => {
    try {
        const logs = await readLogs();
        res.status(200).json(logs);
    } catch (error) {
        console.error('Erişim günlükleri alınırken hata:', error);
        res.status(500).json({ message: 'Erişim günlükleri alınamadı.' });
    }
});


// Yeni bilgilendirme.html rotası
app.get('/bilgilendirme.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'bilgilendirme.html'));
});

// Ana sayfa yönlendirmesi
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Admin.html rotası
app.get('/admin.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});


// Sunucuyu başlat
app.listen(PORT, () => {
    console.log(`Backend sunucusu http://localhost:${PORT} adresinde çalışıyor...`);
    console.log(`Kullanıcı verileri dosyası: ${DB_FILE}`);
    console.log(`Erişim günlükleri dosyası: ${LOG_FILE}`);
});
